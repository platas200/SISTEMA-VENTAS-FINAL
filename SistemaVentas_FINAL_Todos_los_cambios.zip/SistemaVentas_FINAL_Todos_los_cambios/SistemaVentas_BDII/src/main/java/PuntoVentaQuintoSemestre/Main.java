package PuntoVentaQuintoSemestre;

import VIEW.VistaPrincipal;
import VIEW.VistaLogin;
import CONTROLLER.ControladorPrincipal;
import javax.swing.UIManager;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        iniciarApp(); // Llamada inicial
    }

    // Este es el método que faltaba definir
    public static void iniciarApp() {
        SwingUtilities.invokeLater(() -> {
            VistaLogin login = new VistaLogin();
            login.setVisible(true);

            if (login.esAutenticado()) {
                VistaPrincipal vista = new VistaPrincipal();
                new ControladorPrincipal(vista, login.getRol());
                
                vista.setTitle(vista.getTitle() + " - Usuario: " + login.getRol());
                vista.setVisible(true);
            } else {
                // Si el usuario cierra la ventanita del login sin entrar, se cierra el programa
                // Pero si cerramos sesión desde la principal, esto se vuelve a ejecutar
            }
        });
    }
}