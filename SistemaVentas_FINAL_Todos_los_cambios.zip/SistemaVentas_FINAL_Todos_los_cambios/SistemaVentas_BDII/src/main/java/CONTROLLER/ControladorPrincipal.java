package CONTROLLER;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import MODEL.ConsultasCliente;
import MODEL.ConsultasProducto;
import MODEL.ConsultasVenta;
import PuntoVentaQuintoSemestre.Main;
import VIEW.VistaPrincipal;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.*;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Font;


public class ControladorPrincipal implements ActionListener {

    private VistaPrincipal vista;
    private ConsultasProducto modeloProducto;
    private ConsultasCliente modeloCliente;
    private ConsultasVenta modeloVenta;
    private String rolUsuario;

    public ControladorPrincipal(VistaPrincipal vista, String rol) {
        this.vista = vista;
        this.rolUsuario = rol;
        this.modeloProducto = new ConsultasProducto();
        this.modeloCliente = new ConsultasCliente();
        this.modeloVenta = new ConsultasVenta();

        inicializarEventos();
        actualizarTodo();
        aplicarPermisos();
        configurarBuscadores();
        configurarFiltrosTablas();
    }

    private void inicializarEventos() {
        // Evento para el nuevo botón de cerrar sesión
        vista.btnCerrarSesion.addActionListener(this);
        
        vista.btnCrearProd.addActionListener(this);
        vista.btnActProd.addActionListener(this);
        vista.btnEliProd.addActionListener(this);
        vista.btnRefProd.addActionListener(e -> vista.tablaProductos.setModel(modeloProducto.leer()));

        vista.btnCrearCli.addActionListener(this);
        vista.btnActCli.addActionListener(this);
        vista.btnEliCli.addActionListener(this);
        vista.btnRefCli.addActionListener(e -> vista.tablaClientes.setModel(modeloCliente.leer()));

        vista.btnAgregarCarrito.addActionListener(this);
        vista.btnVender.addActionListener(this);
        vista.btnEliminarCarrito.addActionListener(this);
        vista.btnImprimirPDF.addActionListener(this);
        
        vista.btnVaciarCarrito.addActionListener(e -> {
            if (vista.modeloCarrito.getRowCount() > 0) {
                Object[] opciones = {"Sí", "No"};	
                int respuesta = JOptionPane.showOptionDialog(vista, 
                        "¿Estás seguro de que deseas eliminar todos los productos del carrito?", 
                        "Vaciar Carrito", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.QUESTION_MESSAGE, 
                        null, 
                        opciones, 
                        opciones[0]);
                if (respuesta == JOptionPane.YES_OPTION) {
                    vista.modeloCarrito.setRowCount(0);
                    recalculateTotal();
                }
            } else {
                JOptionPane.showMessageDialog(vista, "El carrito ya está vacío.");
            }
        });

        vista.comboProductos.addActionListener(e -> {
            String item = (String) vista.comboProductos.getSelectedItem();
            if (item != null && item.contains(" - ")) {
                String id = item.split(" - ")[0];
                vista.txtPrecioCarrito.setText(String.valueOf(modeloProducto.getPrecio(id)));
            }
        });

        vista.btnRefrescarVentas.addActionListener(e -> vista.tablaVentasHistorial.setModel(modeloVenta.leerVentas()));
        vista.btnEliminarVenta.addActionListener(this);
        
        vista.tablaVentasHistorial.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = vista.tablaVentasHistorial.getSelectedRow();
                if (fila >= 0) {
                    // Convertimos el índice de la vista al índice del modelo por si hay filtros activos
                    int modelRow = vista.tablaVentasHistorial.convertRowIndexToModel(fila);
                    String idVenta = vista.tablaVentasHistorial.getModel().getValueAt(modelRow, 0).toString();
                    vista.tablaDetallesVenta.setModel(modeloVenta.leerDetalles(idVenta));
                }
            }
        });
        
        vista.tablaCarrito.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = vista.tablaCarrito.rowAtPoint(e.getPoint());
                int columna = vista.tablaCarrito.columnAtPoint(e.getPoint());

                if (fila < 0) return;

                int cantidad = Integer.parseInt(
                        vista.modeloCarrito.getValueAt(fila, 3).toString()
                );
                double precio = Double.parseDouble(
                        vista.modeloCarrito.getValueAt(fila, 2).toString()
                );

                if (columna == 4) { // +
                    cantidad++;
                } else if (columna == 5 && cantidad > 1) { // -
                    cantidad--;
                } else {
                    return;
                }

                vista.modeloCarrito.setValueAt(cantidad, fila, 3);
                vista.modeloCarrito.setValueAt(precio * cantidad, fila, 6);

                recalculateTotal();
            }
        });


    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        // Lógica de Cerrar Sesión
        if (source == vista.btnCerrarSesion) {
            int resp = JOptionPane.showConfirmDialog(vista, "¿Desea cerrar la sesión actual?", "Cerrar Sesión", JOptionPane.YES_NO_OPTION);
            if (resp == JOptionPane.YES_OPTION) {
                vista.dispose(); 
                Main.iniciarApp(); // Llama al método que creamos en tu Main
            }
            return; // Salimos para evitar ejecutar el resto
        }
        
        else if (source == vista.btnImprimirPDF) {
            imprimirVentaPDF();
        }
       
        if (source == vista.btnCrearProd) crearProducto();
        else if (source == vista.btnActProd) actualizarProducto();
        else if (source == vista.btnEliProd) eliminarProducto();
        else if (source == vista.btnCrearCli) crearCliente();
        else if (source == vista.btnActCli) actualizarCliente();
        else if (source == vista.btnEliCli) eliminarCliente();
        else if (source == vista.btnAgregarCarrito) agregarAlCarrito();
        else if (source == vista.btnEliminarCarrito) quitarDelCarrito();
        else if (source == vista.btnVender) finalizarVenta();
        else if (source == vista.btnEliminarVenta) eliminarVenta();
    }

    private void crearProducto() {
        try {
            String id = JOptionPane.showInputDialog(vista, "ID del Producto:");
            if (id == null || id.trim().isEmpty()) return;
            String nom = JOptionPane.showInputDialog(vista, "Nombre:");
            if (nom == null || nom.trim().isEmpty()) return;
            String des = JOptionPane.showInputDialog(vista, "Descripción:");
            String resPrecio = JOptionPane.showInputDialog(vista, "Precio:");
            if (!esNumeroDouble(resPrecio)) {
                JOptionPane.showMessageDialog(vista, "Error: Precio inválido.");
                return;
            }
            double pre = Double.parseDouble(resPrecio);
            String resStock = JOptionPane.showInputDialog(vista, "Stock Inicial:");
            if (!esNumeroEntero(resStock)) {
                JOptionPane.showMessageDialog(vista, "Error: Stock inválido.");
                return;
            }
            int sto = Integer.parseInt(resStock);
            if (modeloProducto.crear(id, nom, des, pre, sto)) {
                actualizarTodo();
                JOptionPane.showMessageDialog(vista, "Producto registrado.");
            }
        } catch (Exception ex) { JOptionPane.showMessageDialog(vista, "Error inesperado."); }
    }

    private void actualizarProducto() {
        int fila = vista.tablaProductos.getSelectedRow();
        if (fila < 0) { JOptionPane.showMessageDialog(vista, "Seleccione una fila."); return; }
        try {
            String id = vista.tablaProductos.getValueAt(fila, 0).toString();
            String nom = JOptionPane.showInputDialog(vista, "Nuevo Nombre:", vista.tablaProductos.getValueAt(fila, 1));
            String des = JOptionPane.showInputDialog(vista, "Nueva Descripción:", vista.tablaProductos.getValueAt(fila, 2));
            String resPre = JOptionPane.showInputDialog(vista, "Nuevo Precio:", vista.tablaProductos.getValueAt(fila, 3));
            if (!esNumeroDouble(resPre)) return;
            String resSto = JOptionPane.showInputDialog(vista, "Nuevo Stock:", vista.tablaProductos.getValueAt(fila, 4));
            if (!esNumeroEntero(resSto)) return;
            if (modeloProducto.actualizar(id, nom, des, Double.parseDouble(resPre), Integer.parseInt(resSto))) {
                actualizarTodo();
            }
        } catch (Exception ex) { }
    }

    private void crearCliente() {
        String id = JOptionPane.showInputDialog(vista, "ID Cliente:");
        if (id == null || id.isEmpty()) return;
        String nom = JOptionPane.showInputDialog(vista, "Nombre:");
        String ape = JOptionPane.showInputDialog(vista, "Apellido:");
        String tel = JOptionPane.showInputDialog(vista, "Teléfono (10 dígitos):");
        if (!validarTelefono(tel)) {
            JOptionPane.showMessageDialog(vista, "Error: Teléfono debe tener 10 números.");
            return;
        }
        String dir = JOptionPane.showInputDialog(vista, "Dirección:");
        if (modeloCliente.crear(id, nom, ape, tel, dir)) {
            actualizarTodo();
            JOptionPane.showMessageDialog(vista, "Cliente guardado.");
        }
    }

    private void actualizarCliente() {
        int fila = vista.tablaClientes.getSelectedRow();
        if (fila < 0) return;
        String id = vista.tablaClientes.getValueAt(fila, 0).toString();
        String nom = JOptionPane.showInputDialog(vista, "Nombre:", vista.tablaClientes.getValueAt(fila, 1));
        String ape = JOptionPane.showInputDialog(vista, "Apellido:", vista.tablaClientes.getValueAt(fila, 2));
        String tel = JOptionPane.showInputDialog(vista, "Teléfono:", vista.tablaClientes.getValueAt(fila, 3));
        if (!validarTelefono(tel)) {
            JOptionPane.showMessageDialog(vista, "Teléfono inválido.");
            return;
        }
        String dir = JOptionPane.showInputDialog(vista, "Dirección:", vista.tablaClientes.getValueAt(fila, 4));
        if (modeloCliente.actualizar(id, nom, ape, tel, dir)) actualizarTodo();
    }

    private boolean esNumeroDouble(String str) {
        if (str == null) return false;
        try { return Double.parseDouble(str) >= 0; } catch (NumberFormatException e) { return false; }
    }

    private boolean esNumeroEntero(String str) {
        if (str == null) return false;
        try { return Integer.parseInt(str) >= 0; } catch (NumberFormatException e) { return false; }
    }

    private boolean validarTelefono(String tel) {
        return tel != null && tel.matches("\\d{10}");
    }

    private void configurarFiltrosTablas() {
        // === FILTRO PRODUCTOS ===
        // Obtenemos el sorter que ya tiene la lógica de comparación P1, P2...
        if (vista.tablaProductos.getRowSorter() instanceof TableRowSorter) {
            TableRowSorter<DefaultTableModel> sorterProd = (TableRowSorter<DefaultTableModel>) vista.tablaProductos.getRowSorter();
            
            vista.txtBuscaProd.addKeyListener(new KeyAdapter() {
                @Override
                public void keyReleased(KeyEvent e) {
                    String texto = vista.txtBuscaProd.getText().trim();
                    if (texto.isEmpty()) {
                        sorterProd.setRowFilter(null);
                    } else {
                        // Filtra por ID (0), Nombre (1) y Descripción (2)
                        sorterProd.setRowFilter(RowFilter.regexFilter("(?i)" + texto, 0, 1, 2));
                    }
                }
            });
        }

        // === FILTRO CLIENTES ===
        if (vista.tablaClientes.getRowSorter() instanceof TableRowSorter) {
            TableRowSorter<DefaultTableModel> sorterCli = (TableRowSorter<DefaultTableModel>) vista.tablaClientes.getRowSorter();
            
            vista.txtBuscaCli.addKeyListener(new KeyAdapter() {
                @Override
                public void keyReleased(KeyEvent e) {
                    String texto = vista.txtBuscaCli.getText().trim();
                    if (texto.isEmpty()) {
                        sorterCli.setRowFilter(null);
                    } else {
                        // Filtra por ID (0) y Nombre (1)
                        sorterCli.setRowFilter(RowFilter.regexFilter("(?i)" + texto, 0, 1));
                    }
                }
            });
        }

        // === FILTRO HISTORIAL ===
        if (vista.tablaVentasHistorial.getRowSorter() instanceof TableRowSorter) {
            TableRowSorter<DefaultTableModel> sorterHist = (TableRowSorter<DefaultTableModel>) vista.tablaVentasHistorial.getRowSorter();
            
            vista.txtBuscaHistorial.addKeyListener(new KeyAdapter() {
                @Override
                public void keyReleased(KeyEvent e) {
                    String texto = vista.txtBuscaHistorial.getText().trim();
                    if (texto.isEmpty()) {
                        sorterHist.setRowFilter(null);
                    } else {
                        sorterHist.setRowFilter(RowFilter.regexFilter("(?i)" + texto));
                    }
                }
            });
        }
    }
    
    private void eliminarProducto() {
        int f = vista.tablaProductos.getSelectedRow();
        if (f >= 0 && JOptionPane.showConfirmDialog(vista, "¿Borrar?") == 0) {
            if (modeloProducto.borrar(vista.tablaProductos.getValueAt(f, 0).toString())) actualizarTodo();
        }
    }

    private void eliminarCliente() {
        int f = vista.tablaClientes.getSelectedRow();
        if (f >= 0 && JOptionPane.showConfirmDialog(vista, "¿Borrar cliente?") == 0) {
            if (modeloCliente.borrar(vista.tablaClientes.getValueAt(f, 0).toString())) actualizarTodo();
        }
    }

    private void agregarAlCarrito() {
        try {
            String item = (String) vista.comboProductos.getSelectedItem();
            String id = item.split(" - ")[0];
            String nom = item.split(" - ")[1];
            double pre = Double.parseDouble(vista.txtPrecioCarrito.getText());

            int filaExistente = buscarProductoEnCarrito(id);

            if (filaExistente >= 0) {
                modificarCantidad(filaExistente, 1);
            } else {
                vista.modeloCarrito.addRow(new Object[]{
                    id, nom, pre, 1, "+", "-", pre
                });
                recalculateTotal();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Error al agregar al carrito.");
        }
    }


    private void quitarDelCarrito() {
        int f = vista.tablaCarrito.getSelectedRow();
        if (f >= 0) {
            vista.modeloCarrito.removeRow(f);
            recalculateTotal();
        }
    }

    private void configurarBuscadores() {
        // --- BUSCADOR DE CLIENTES ---
        JTextField editorCliente = (JTextField) vista.comboClientes.getEditor().getEditorComponent();
        editorCliente.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER || e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_DOWN) return;
                String filtro = editorCliente.getText().toLowerCase();
                DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
                for (String c : modeloCliente.obtenerListaClientes()) {
                    if (c.toLowerCase().contains(filtro)) modelo.addElement(c);
                }
                vista.comboClientes.setModel(modelo);
                editorCliente.setText(filtro);
                if (modelo.getSize() > 0) vista.comboClientes.showPopup();
            }
        });

        // --- BUSCADOR DE PRODUCTOS ---
        JTextField editorProducto = (JTextField) vista.comboProductos.getEditor().getEditorComponent();
        editorProducto.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER || e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_DOWN) return;
                String filtro = editorProducto.getText().toLowerCase();
                DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
                for (String p : modeloProducto.obtenerListaProductos()) {
                    if (p.toLowerCase().contains(filtro)) modelo.addElement(p);
                }
                vista.comboProductos.setModel(modelo);
                editorProducto.setText(filtro);
                if (modelo.getSize() > 0) vista.comboProductos.showPopup();
            }
        });
    }

    private void finalizarVenta() {
        if (vista.modeloCarrito.getRowCount() == 0) return;
        
        String idCli = ((String) vista.comboClientes.getSelectedItem()).split(" - ")[0];
        List<String> ids = new ArrayList<>();
        List<Integer> cants = new ArrayList<>();
        
        for (int i = 0; i < vista.modeloCarrito.getRowCount(); i++) {
            ids.add(vista.modeloCarrito.getValueAt(i, 0).toString());
            cants.add(Integer.parseInt(vista.modeloCarrito.getValueAt(i, 3).toString()));
        }
        
        if (modeloVenta.realizarVenta(idCli, ids, cants).equals("OK")) {
            JOptionPane.showMessageDialog(vista, "¡Venta Exitosa!");
            
            // 1. Limpiar carrito
            vista.modeloCarrito.setRowCount(0);
            recalculateTotal();
            
            // 2. RECARGAR DATOS DE LA DB (Esto es lo que te faltaba para que sea instantáneo)
            vista.tablaVentasHistorial.setModel(modeloVenta.leerVentas());
            vista.tablaProductos.setModel(modeloProducto.leer());
            
            // 3. RE-VINCULAR LOS FILTROS Y EL ORDEN
            // Si no haces esto, la tabla se queda "congelada" con el sorter viejo
            aplicarOrdenamientoTablas(); 
            configurarFiltrosTablas(); 

            // 4. Forzar refresco visual
            vista.tablaVentasHistorial.repaint();
            vista.tablaVentasHistorial.revalidate();
            
            refrescarTablasDespuesDeVenta();
        }
    }

    private void eliminarVenta() {
        int f = vista.tablaVentasHistorial.getSelectedRow();
        if (f >= 0) {
            String id = vista.tablaVentasHistorial.getValueAt(f, 0).toString();
            if (modeloVenta.eliminarVenta(id)) {
                actualizarTodo();
                vista.tablaDetallesVenta.setModel(new DefaultTableModel());
            }
        }
    }

    private void recalculateTotal() {
        double total = 0;
        for (int i = 0; i < vista.modeloCarrito.getRowCount(); i++) {
            total += Double.parseDouble(
                vista.modeloCarrito.getValueAt(i, 6).toString()
            );
        }
        vista.lblTotalCarrito.setText("TOTAL: $" + total);
    }


    private void actualizarTodo() {
        // --- PRODUCTOS ---
        DefaultTableModel modeloProd = modeloProducto.leer();
        vista.tablaProductos.setModel(modeloProd);
        TableRowSorter<DefaultTableModel> sorterProd = new TableRowSorter<>(modeloProd);
        // Comparador para ignorar la letra y ordenar por el número
        sorterProd.setComparator(0, (o1, o2) -> {
            Integer n1 = Integer.parseInt(o1.toString().replaceAll("\\D", ""));
            Integer n2 = Integer.parseInt(o2.toString().replaceAll("\\D", ""));
            return n1.compareTo(n2);
        });
        vista.tablaProductos.setRowSorter(sorterProd);

        // --- CLIENTES ---
        DefaultTableModel modeloCli = modeloCliente.leer();
        vista.tablaClientes.setModel(modeloCli);
        TableRowSorter<DefaultTableModel> sorterCli = new TableRowSorter<>(modeloCli);
        sorterCli.setComparator(0, (o1, o2) -> {
            Integer n1 = Integer.parseInt(o1.toString().replaceAll("\\D", ""));
            Integer n2 = Integer.parseInt(o2.toString().replaceAll("\\D", ""));
            return n1.compareTo(n2);
        });
        vista.tablaClientes.setRowSorter(sorterCli);

        // --- VENTAS HISTORIAL ---
        DefaultTableModel modeloVta = modeloVenta.leerVentas();
        vista.tablaVentasHistorial.setModel(modeloVta);
        TableRowSorter<DefaultTableModel> sorterVta = new TableRowSorter<>(modeloVta);
        sorterVta.setComparator(0, (o1, o2) -> {
            Integer n1 = Integer.parseInt(o1.toString().replaceAll("\\D", ""));
            Integer n2 = Integer.parseInt(o2.toString().replaceAll("\\D", ""));
            return n1.compareTo(n2);
        });
        vista.tablaVentasHistorial.setRowSorter(sorterVta);

        // Actualizar Combos
        vista.comboClientes.removeAllItems();
        modeloCliente.obtenerListaClientes().forEach(vista.comboClientes::addItem);

        vista.comboProductos.removeAllItems();
        modeloProducto.obtenerListaProductos().forEach(vista.comboProductos::addItem);
        
        aplicarOrdenamientoTablas();
        configurarFiltrosTablas();
    }

    private void aplicarPermisos() {
        if (rolUsuario != null && rolUsuario.equalsIgnoreCase("Vendedor")) {
            vista.pestañas.setEnabledAt(0, false);
            vista.pestañas.setEnabledAt(1, false);
            vista.pestañas.setSelectedIndex(2);
        }
    }
    
    private void aplicarOrdenamientoTablas() {
        // Sorter Historial
        TableRowSorter<DefaultTableModel> sorterVta = new TableRowSorter<>((DefaultTableModel) vista.tablaVentasHistorial.getModel());
        sorterVta.setComparator(0, (o1, o2) -> {
            Integer n1 = Integer.parseInt(o1.toString().replaceAll("\\D", ""));
            Integer n2 = Integer.parseInt(o2.toString().replaceAll("\\D", ""));
            return n1.compareTo(n2);
        });
        vista.tablaVentasHistorial.setRowSorter(sorterVta);
        sorterVta.sort(); // <--- Fuerza a la tabla a acomodar la nueva venta arriba o abajo según el orden

        // Sorter Productos
        TableRowSorter<DefaultTableModel> sorterProd = new TableRowSorter<>((DefaultTableModel) vista.tablaProductos.getModel());
        sorterProd.setComparator(0, (o1, o2) -> {
            Integer n1 = Integer.parseInt(o1.toString().replaceAll("\\D", ""));
            Integer n2 = Integer.parseInt(o2.toString().replaceAll("\\D", ""));
            return n1.compareTo(n2);
        });
        vista.tablaProductos.setRowSorter(sorterProd);
        sorterProd.sort();
    }
    
    private void refrescarTablasDespuesDeVenta() {
        // 1. Cargar datos nuevos de la DB a los modelos
        DefaultTableModel modeloVentasNuevas = modeloVenta.leerVentas();
        DefaultTableModel modeloProductosNuevos = modeloProducto.leer();

        // 2. Inyectar modelos a las tablas
        vista.tablaVentasHistorial.setModel(modeloVentasNuevas);
        vista.tablaProductos.setModel(modeloProductosNuevos);

        // 3. RE-APLICAR EL ORDENAMIENTO (Esto fuerza a la tabla a mostrar lo nuevo)
        aplicarOrdenamientoTablas(); 

        // 4. RE-CONECTAR LOS BUSCADORES (Para que no dejen de funcionar)
        configurarFiltrosTablas();

        // 5. Forzar a Java Swing a dibujar los cambios
        vista.tablaVentasHistorial.revalidate();
        vista.tablaVentasHistorial.repaint();
        vista.tablaProductos.revalidate();
        vista.tablaProductos.repaint();
    }
    
    private void imprimirVentaPDF() {
        int fila = vista.tablaVentasHistorial.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(vista, "Selecciona una venta primero.");
            return;
        }

        int modelRow = vista.tablaVentasHistorial.convertRowIndexToModel(fila);
        String idVenta = vista.tablaVentasHistorial.getModel()
                .getValueAt(modelRow, 0).toString();

        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("Venta_" + idVenta + ".pdf"));

        if (chooser.showSaveDialog(vista) != JFileChooser.APPROVE_OPTION) return;

        try {
            Document doc = new Document(PageSize.A4);
            PdfWriter.getInstance(doc, new FileOutputStream(chooser.getSelectedFile()));
            doc.open();

            // ===== ENCABEZADO =====
            com.itextpdf.text.Font titulo = new com.itextpdf.text.Font(
            		com.itextpdf.text.Font.FontFamily.COURIER,16,com.itextpdf.text.Font.BOLD);
            		
            Paragraph encabezado = new Paragraph(
                    "EMPRESA TECNOLÓGICA\nGRUPO TECNO PLATINO\n\n");
            encabezado.setFont(titulo);
            encabezado.setAlignment(Element.ALIGN_CENTER);
            doc.add(encabezado);

            // ===== DATOS DE VENTA =====
            com.itextpdf.text.Font normal =
                    new com.itextpdf.text.Font(
                            com.itextpdf.text.Font.FontFamily.COURIER,
                            11
                    );

            Paragraph p1 = new Paragraph("ID Venta: " + idVenta);
            p1.setFont(normal);
            doc.add(p1);

            Paragraph p2 = new Paragraph("Fecha: " +
                    vista.tablaVentasHistorial.getModel().getValueAt(modelRow, 1));
            p2.setFont(normal);
            doc.add(p2);

            Paragraph p3 = new Paragraph("Total: $" +
                    vista.tablaVentasHistorial.getModel().getValueAt(modelRow, 2));
            p3.setFont(normal);
            doc.add(p3);

            doc.add(new Paragraph("\n"));

            // ===== TABLA DETALLES =====
            PdfPTable tabla = new PdfPTable(4);
            tabla.setWidthPercentage(100);
            tabla.setWidths(new float[]{4, 2, 2, 2});

            tabla.addCell("Producto");
            tabla.addCell("Cantidad");
            tabla.addCell("Precio");
            tabla.addCell("Subtotal");

            DefaultTableModel detalles =
                    (DefaultTableModel) vista.tablaDetallesVenta.getModel();

            for (int i = 0; i < detalles.getRowCount(); i++) {
                tabla.addCell(detalles.getValueAt(i, 2).toString());
                tabla.addCell(detalles.getValueAt(i, 3).toString());
                tabla.addCell("$" + detalles.getValueAt(i, 4));
                tabla.addCell("$" + detalles.getValueAt(i, 5));
            }

            doc.add(tabla);

            // ===== PIE =====
            com.itextpdf.text.Font italica =
                    new com.itextpdf.text.Font(
                            com.itextpdf.text.Font.FontFamily.COURIER,
                            10,
                            com.itextpdf.text.Font.ITALIC
                    );
            Paragraph gracias = new Paragraph("\nGracias por su compra.");
            gracias.setFont(italica);
            gracias.setAlignment(Element.ALIGN_CENTER);
            doc.add(gracias);

            doc.close();

            JOptionPane.showMessageDialog(vista, "PDF generado correctamente.");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Error al generar PDF.");
            ex.printStackTrace();
        }
    }
    
    private int buscarProductoEnCarrito(String idProducto) {
        for (int i = 0; i < vista.modeloCarrito.getRowCount(); i++) {
            if (vista.modeloCarrito.getValueAt(i, 0).equals(idProducto)) {
                return i;
            }
        }
        return -1;
    }
    
    private void modificarCantidad(int fila, int cambio) {
        int cantidad = Integer.parseInt(
            vista.modeloCarrito.getValueAt(fila, 3).toString()
        );

        double precio = Double.parseDouble(
            vista.modeloCarrito.getValueAt(fila, 2).toString()
        );

        cantidad += cambio;

        if (cantidad < 1) return;

        double nuevoSubtotal = cantidad * precio;

        vista.modeloCarrito.setValueAt(cantidad, fila, 3);
        vista.modeloCarrito.setValueAt(nuevoSubtotal, fila, 6);

        recalculateTotal();
    }


}